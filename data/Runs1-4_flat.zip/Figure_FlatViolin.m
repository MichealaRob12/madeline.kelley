%% trying to make violin vertical plots for Flat runs using mean track info

clc
clear 
p_scale = 168;

%%
load('FlatTracks_v2.mat', 'Flat13Tracks')
Flat13Tracks.x = Flat13Tracks.x_start/p_scale;
Flat13Tracks.y = (max(Flat13Tracks.y_start)-Flat13Tracks.y_start)/p_scale;
load('FlatTracks_v2.mat', 'Flat14Tracks')
Flat14Tracks.x = Flat14Tracks.x_start/p_scale;
Flat14Tracks.y = (max(Flat14Tracks.y_start)-Flat14Tracks.y_start)/p_scale;
load('FlatTracks_v2.mat', 'Flat15Tracks')
Flat15Tracks.x = Flat15Tracks.x_start/p_scale;
Flat15Tracks.y = (max(Flat15Tracks.y_start)-Flat15Tracks.y_start)/p_scale;
load('FlatTracks_v2.mat', 'Flat16Tracks')
Flat16Tracks.x = Flat16Tracks.x_start/p_scale;
Flat16Tracks.y = (max(Flat16Tracks.y_start)-Flat16Tracks.y_start)/p_scale;
load('FlatTracks_v2.mat', 'Flat17Tracks')
Flat17Tracks.x = Flat17Tracks.x_start/p_scale;
Flat17Tracks.y = (max(Flat17Tracks.y_start)-Flat17Tracks.y_start)/p_scale;


%% Vertbins Flat13
for i=1:(length(Flat13Tracks.y))
   if Flat13Tracks.y(i) <= 0.5   
      motionYb(i,1) = 1;
   elseif Flat13Tracks.y(i) <=1.0 
       motionYb(i,1) = 2;    
   elseif Flat13Tracks.y(i) <=2.0 
       motionYb(i,1) = 3; 
   elseif Flat13Tracks.y(i) <=5.0 
       motionYb(i,1) = 4; 
   end
end
Flat13Tracks.ybin = motionYb;% Creates a new column that places track location into a bin
Flat13Tracksb1 = Flat13Tracks(Flat13Tracks.ybin==1,:);

Flat13Tracksb2 = Flat13Tracks(Flat13Tracks.ybin==2,:);

Flat13Tracksb3 = Flat13Tracks(Flat13Tracks.ybin==3,:);

Flat13Tracksb4 = Flat13Tracks(Flat13Tracks.ybin==4,:);
  
%% Track vel mean f13 b1

[f13Track,~,subsf13] = unique(Flat13Tracksb1.track_number);
f13u = accumarray(subsf13,Flat13Tracksb1.velx,[],@mean);
f13v = accumarray(subsf13,Flat13Tracksb1.vely,[],@mean);

Trackf13b1 = [f13Track, f13u,f13v];
x_Trackf13b1=ones(size(f13Track)).*0.5;

b1_13 = [(mean(f13u)+(std(f13u).*2)),(mean(f13u)-(std(f13u).*2))];
b1_13v = [(mean(f13v)+(std(f13v).*2)),(mean(f13v)-(std(f13v).*2))];


%% Track vel mean f13 b2

[f13Track,~,subsf13] = unique(Flat13Tracksb2.track_number);
f13u = accumarray(subsf13,Flat13Tracksb2.velx,[],@mean);
f13v = accumarray(subsf13,Flat13Tracksb2.vely,[],@mean);

Trackf13b2 = [f13Track, f13u,f13v];
x_Trackf13b2=ones(size(f13Track));

b2_13 = [(mean(f13u)+(std(f13u).*2)),(mean(f13u)-(std(f13u).*2))];
b2_13v = [(mean(f13v)+(std(f13v).*2)),(mean(f13v)-(std(f13v).*2))];

%% Track vel mean f13 b3

[f13Track,~,subsf13] = unique(Flat13Tracksb3.track_number);
f13u = accumarray(subsf13,Flat13Tracksb3.velx,[],@mean);
f13v = accumarray(subsf13,Flat13Tracksb3.vely,[],@mean);
Trackf13b3 = [f13Track, f13u,f13v];
x_Trackf13b3=ones(size(f13Track)).*2.0;

b3_13 = [(mean(f13u)+(std(f13u).*2)),(mean(f13u)-(std(f13u).*2))];
b3_13v = [(mean(f13v)+(std(f13v).*2)),(mean(f13v)-(std(f13v).*2))];

%% Track vel mean f13 b4

[f13Track,~,subsf13] = unique(Flat13Tracksb4.track_number);
f13u = accumarray(subsf13,Flat13Tracksb4.velx,[],@mean);
f13v = accumarray(subsf13,Flat13Tracksb4.vely,[],@mean);
Trackf13b4 = [f13Track, f13u,f13v];
x_Trackf13b4=ones(size(f13Track)).*4.0;

b4_13 = [(mean(f13u)+(std(f13u).*2)),(mean(f13u)-(std(f13u).*2))];
b4_13v = [(mean(f13v)+(std(f13v).*2)),(mean(f13v)-(std(f13v).*2))];

%% OUT ALL run 1
Trackf13 = [Trackf13b1;Trackf13b2;Trackf13b3;Trackf13b4];
x_Trackf13= [x_Trackf13b1;x_Trackf13b2;x_Trackf13b3;x_Trackf13b4];

%% Vertbins Flat14
for i=1:(length(Flat14Tracks.y))
   if Flat14Tracks.y(i) <= 0.5   
      motionYb(i,1) = 1;
   elseif Flat14Tracks.y(i) <=1.0 
       motionYb(i,1) = 2;    
   elseif Flat14Tracks.y(i) <=2.0 
       motionYb(i,1) = 3; 
   elseif Flat14Tracks.y(i) <=5.0 
       motionYb(i,1) = 4; 
   end
end
Flat14Tracks.ybin = motionYb;% Creates a new column that places track location into a bin
Flat14Tracksb1 = Flat14Tracks(Flat14Tracks.ybin==1,:);

Flat14Tracksb2 = Flat14Tracks(Flat14Tracks.ybin==2,:);

Flat14Tracksb3 = Flat14Tracks(Flat14Tracks.ybin==3,:);

Flat14Tracksb4 = Flat14Tracks(Flat14Tracks.ybin==4,:);

  
%% Track vel mean f14 b1

[f14Track,~,subsf14] = unique(Flat14Tracksb1.track_number);
f14u = accumarray(subsf14,Flat14Tracksb1.velx,[],@mean);
f14v = accumarray(subsf14,Flat14Tracksb1.vely,[],@mean);
Trackf14b1 = [f14Track, f14u,f14v];
x_Trackf14b1=ones(size(f14Track)).*0.5;

b1_14 = [(mean(f14u)+(std(f14u).*2)),(mean(f14u)-(std(f14u).*2))];
b1_14v = [(mean(f14v)+(std(f14v).*2)),(mean(f14v)-(std(f14v).*2))];

%% Track vel mean f14 b2

[f14Track,~,subsf14] = unique(Flat14Tracksb2.track_number);
f14u = accumarray(subsf14,Flat14Tracksb2.velx,[],@mean);
f14v = accumarray(subsf14,Flat14Tracksb2.vely,[],@mean);
Trackf14b2 = [f14Track, f14u,f14v];
x_Trackf14b2=ones(size(f14Track));
b2_14 = [(mean(f14u)+(std(f14u).*2)),(mean(f14u)-(std(f14u).*2))];
b2_14v = [(mean(f14v)+(std(f14v).*2)),(mean(f14v)-(std(f14v).*2))];

%% Track vel mean f14 b3

[f14Track,~,subsf14] = unique(Flat14Tracksb3.track_number);
f14u = accumarray(subsf14,Flat14Tracksb3.velx,[],@mean);
f14v = accumarray(subsf14,Flat14Tracksb3.vely,[],@mean);
Trackf14b3 = [f14Track, f14u,f14v];
x_Trackf14b3=ones(size(f14Track)).*2.0;
b3_14 = [(mean(f14u)+(std(f14u).*2)),(mean(f14u)-(std(f14u).*2))];
b3_14v = [(mean(f14v)+(std(f14v).*2)),(mean(f14v)-(std(f14v).*2))];

%% Track vel mean f14 b4

[f14Track,~,subsf14] = unique(Flat14Tracksb4.track_number);
f14u = accumarray(subsf14,Flat14Tracksb4.velx,[],@mean);
f14v = accumarray(subsf14,Flat14Tracksb4.vely,[],@mean);
Trackf14b4 = [f14Track, f14u,f14v];
x_Trackf14b4=ones(size(f14Track)).*4.0;
b4_14 = [(mean(f14u)+(std(f14u).*2)),(mean(f14u)-(std(f14u).*2))];
b4_14v = [(mean(f14v)+(std(f14v).*2)),(mean(f14v)-(std(f14v).*2))];


%% OUT ALL run2
Trackf14 = [Trackf14b1;Trackf14b2;Trackf14b3;Trackf14b4];
x_Trackf14= [x_Trackf14b1;x_Trackf14b2;x_Trackf14b3;x_Trackf14b4];

%% Vertbins Flat16
for i=1:(length(Flat16Tracks.y))
   if Flat16Tracks.y(i) <= 0.5   
      motionYb(i,1) = 1;
   elseif Flat16Tracks.y(i) <=1.0 
       motionYb(i,1) = 2;    
   elseif Flat16Tracks.y(i) <=2.0 
       motionYb(i,1) = 3; 
   elseif Flat16Tracks.y(i) <=5.0 
       motionYb(i,1) = 4; 
   end
end
Flat16Tracks.ybin = motionYb;% Creates a new column that places track location into a bin
Flat16Tracksb1 = Flat16Tracks(Flat16Tracks.ybin==1,:);

Flat16Tracksb2 = Flat16Tracks(Flat16Tracks.ybin==2,:);

Flat16Tracksb3 = Flat16Tracks(Flat16Tracks.ybin==3,:);

Flat16Tracksb4 = Flat16Tracks(Flat16Tracks.ybin==4,:);

  
%% Track vel mean f16 b1

[f16Track,~,subsf16] = unique(Flat16Tracksb1.track_number);
f16u = accumarray(subsf16,Flat16Tracksb1.velx,[],@mean);
f16v = accumarray(subsf16,Flat16Tracksb1.vely,[],@mean);
Trackf16b1 = [f16Track, f16u,f16v];
x_Trackf16b1=ones(size(f16Track)).*0.5;
b1_16 = [(mean(f16u)+(std(f16u).*2)),(mean(f16u)-(std(f16u).*2))];
b1_16v = [(mean(f16v)+(std(f16v).*2)),(mean(f16v)-(std(f16v).*2))];

%% Track vel mean f16 b2

[f16Track,~,subsf16] = unique(Flat16Tracksb2.track_number);
f16u = accumarray(subsf16,Flat16Tracksb2.velx,[],@mean);
f16v = accumarray(subsf16,Flat16Tracksb2.vely,[],@mean);
Trackf16b2 = [f16Track, f16u,f16v];
x_Trackf16b2=ones(size(f16Track));
b2_16 = [(mean(f16u)+(std(f16u).*2)),(mean(f16u)-(std(f16u).*2))];
b2_16v = [(mean(f16v)+(std(f16v).*2)),(mean(f16v)-(std(f16v).*2))];

%% Track vel mean f16 b3

[f16Track,~,subsf16] = unique(Flat16Tracksb3.track_number);
f16u = accumarray(subsf16,Flat16Tracksb3.velx,[],@mean);
f16v = accumarray(subsf16,Flat16Tracksb3.vely,[],@mean);
Trackf16b3 = [f16Track, f16u,f16v];
x_Trackf16b3=ones(size(f16Track)).*2.0;
b3_16 = [(mean(f16u)+(std(f16u).*2)),(mean(f16u)-(std(f16u).*2))];
b3_16v = [(mean(f16v)+(std(f16v).*2)),(mean(f16v)-(std(f16v).*2))];

%% Track vel mean f16 b4

[f16Track,~,subsf16] = unique(Flat16Tracksb4.track_number);
f16u = accumarray(subsf16,Flat16Tracksb4.velx,[],@mean);
f16v = accumarray(subsf16,Flat16Tracksb4.vely,[],@mean);
Trackf16b4 = [f16Track, f16u,f16v];
x_Trackf16b4=ones(size(f16Track)).*4.0;

b4_16 = [(mean(f16u)+(std(f16u).*2)),(mean(f16u)-(std(f16u).*2))];
b4_16v = [(mean(f16v)+(std(f16v).*2)),(mean(f16v)-(std(f16v).*2))];

%% OUT ALL run 3
Trackf16 = [Trackf16b1;Trackf16b2;Trackf16b3;Trackf16b4];
x_Trackf16= [x_Trackf16b1;x_Trackf16b2;x_Trackf16b3;x_Trackf16b4];

%% Vertbins Flat17
for i=1:(length(Flat17Tracks.y))
   if Flat17Tracks.y(i) <= 0.5   
      motionYb(i,1) = 1;
   elseif Flat17Tracks.y(i) <=1.0 
       motionYb(i,1) = 2;    
   elseif Flat17Tracks.y(i) <=2.0 
       motionYb(i,1) = 3; 
   elseif Flat17Tracks.y(i) <=5.0 
       motionYb(i,1) = 4; 
   end
end
Flat17Tracks.ybin = motionYb;% Creates a new column that places track location into a bin
Flat17Tracksb1 = Flat17Tracks(Flat17Tracks.ybin==1,:);

Flat17Tracksb2 = Flat17Tracks(Flat17Tracks.ybin==2,:);

Flat17Tracksb3 = Flat17Tracks(Flat17Tracks.ybin==3,:);

Flat17Tracksb4 = Flat17Tracks(Flat17Tracks.ybin==4,:);


%% Track vel mean f17 b1

[f17Track,~,subsf17] = unique(Flat17Tracksb1.track_number);
f17u = accumarray(subsf17,Flat17Tracksb1.velx,[],@mean);
f17v = accumarray(subsf17,Flat17Tracksb1.vely,[],@mean);
Trackf17b1 = [f17Track, f17u,f17v];
x_Trackf17b1=ones(size(f17Track)).*0.5;

b1_17 = [(mean(f17u)+(std(f17u).*2)),(mean(f17u)-(std(f17u).*2))];
b1_17v = [(mean(f17v)+(std(f17v).*2)),(mean(f17v)-(std(f17v).*2))];

%% Track vel mean f17 b2

[f17Track,~,subsf17] = unique(Flat17Tracksb2.track_number);
f17u = accumarray(subsf17,Flat17Tracksb2.velx,[],@mean);
f17v = accumarray(subsf17,Flat17Tracksb2.vely,[],@mean);
Trackf17b2 = [f17Track, f17u,f17v];
x_Trackf17b2=ones(size(f17Track));
b2_17 = [(mean(f17u)+(std(f17u).*2)),(mean(f17u)-(std(f17u).*2))];
b2_17v = [(mean(f17v)+(std(f17v).*2)),(mean(f17v)-(std(f17v).*2))];
%% Track vel mean f17 b3

[f17Track,~,subsf17] = unique(Flat17Tracksb3.track_number);
f17u = accumarray(subsf17,Flat17Tracksb3.velx,[],@mean);
f17v = accumarray(subsf17,Flat17Tracksb3.vely,[],@mean);
Trackf17b3 = [f17Track, f17u,f17v];
x_Trackf17b3=ones(size(f17Track)).*2.0;
b3_17 = [(mean(f17u)+(std(f17u).*2)),(mean(f17u)-(std(f17u).*2))];
b3_17v = [(mean(f17v)+(std(f17v).*2)),(mean(f17v)-(std(f17v).*2))];
%% Track vel mean f17 b4

[f17Track,~,subsf17] = unique(Flat17Tracksb4.track_number);
f17u = accumarray(subsf17,Flat17Tracksb4.velx,[],@mean);
f17v = accumarray(subsf17,Flat17Tracksb4.vely,[],@mean);
Trackf17b4 = [f17Track, f17u,f17v];
x_Trackf17b4=ones(size(f17Track)).*4.0;

b4_17 = [(mean(f17u)+(std(f17u).*2)),(mean(f17u)-(std(f17u).*2))];
b4_17v = [(mean(f17v)+(std(f17v).*2)),(mean(f17v)-(std(f17v).*2))];
%% OUT ALL run 4
Trackf17 = [Trackf17b1;Trackf17b2;Trackf17b3;Trackf17b4];
x_Trackf17= [x_Trackf17b1;x_Trackf17b2;x_Trackf17b3;x_Trackf17b4];


%% Flatbed mean tracks violin plots Fig 15
%Trackl16 = [l16Track, l16u,l16v,dirl16,magl16];
clc
figure (1)
clf
subplot(2,2,1)
violinplot(Trackf13(:,2),x_Trackf13,'HalfViolin','right','ViolinColor',[0.92,0.58,0.64],'ShowData',false,'ShowMean', true,'EdgeColor',[0.64 0.08 0.18],'ViolinAlpha',0.6,'Width',0.5,'Bandwidth',.3,'QuartileStyle','none','MarkerSize',100);
violinplot(Trackf13(:,3),x_Trackf13,'HalfViolin','left', 'ViolinColor',[0.40,0.40,0.40],'ShowData',false,'ShowMean', true,'EdgeColor',[0.3 0.3 0.3],'ViolinAlpha',0.6,'Width',0.5,'Bandwidth',.3,'QuartileStyle','none','MarkerSize',100);hold on
scatter([1,1],b1_13,'Marker','v','MarkerEdgeColor','[0.64 0.08 0.18]','MarkerFaceColor','[0.64 0.08 0.18]','SizeData',20)
scatter([1,1],b1_13v,'Marker','v','MarkerEdgeColor','[0.2 0.2 0.2]','MarkerFaceColor','[0.2 0.2 0.2]','SizeData',20)
scatter([2,2],b2_13,'Marker','v','MarkerEdgeColor','[0.64 0.08 0.18]','MarkerFaceColor','[0.64 0.08 0.18]','SizeData',20)
scatter([2,2],b2_13v,'Marker','v','MarkerEdgeColor','[0.2 0.2 0.2]','MarkerFaceColor','[0.2 0.2 0.2]','SizeData',20)
scatter([3,3],b3_13,'Marker','v','MarkerEdgeColor','[0.64 0.08 0.18]','MarkerFaceColor','[0.64 0.08 0.18]','SizeData',20)
scatter([3,3],b3_13v,'Marker','v','MarkerEdgeColor','[0.2 0.2 0.2]','MarkerFaceColor','[0.2 0.2 0.2]','SizeData',20)
scatter([4,4],b4_13,'Marker','v','MarkerEdgeColor','[0.64 0.08 0.18]','MarkerFaceColor','[0.64 0.08 0.18]','SizeData',20)
scatter([4,4],b4_13v,'Marker','v','MarkerEdgeColor','[0.2 0.2 0.2]','MarkerFaceColor','[0.2 0.2 0.2]','SizeData',20)
set( gca, 'YDir', 'reverse','YMinorGrid','on','FontSize',20)
camroll(90);
ylim([-6 6])
ylabel('particle velocities (ms^-^1)')
xlabel('vertical bin heigth (cm)')
%title('Run 1')
grid on

subplot(2,2,2)
violinplot(Trackf14(:,2),x_Trackf14,'HalfViolin','right','ViolinColor',[0.92,0.58,0.64],'ShowData',false,'ShowMean', true,'EdgeColor',[0.64 0.08 0.18],'ViolinAlpha',0.6,'Width',0.5,'Bandwidth',.3,'QuartileStyle','none','MarkerSize',100);
violinplot(Trackf14(:,3),x_Trackf14,'HalfViolin','left', 'ViolinColor',[0.40,0.40,0.40],'ShowData',false,'ShowMean', true,'EdgeColor',[0.3 0.3 0.3],'ViolinAlpha',0.6,'Width',0.5,'Bandwidth',.3,'QuartileStyle','none','MarkerSize',100);hold on
scatter([1,1],b1_14,'Marker','v','MarkerEdgeColor','[0.64 0.08 0.18]','MarkerFaceColor','[0.64 0.08 0.18]','SizeData',20)
scatter([1,1],b1_14v,'Marker','v','MarkerEdgeColor','[0.2 0.2 0.2]','MarkerFaceColor','[0.2 0.2 0.2]','SizeData',20)
scatter([2,2],b2_14,'Marker','v','MarkerEdgeColor','[0.64 0.08 0.18]','MarkerFaceColor','[0.64 0.08 0.18]','SizeData',20)
scatter([2,2],b2_14v,'Marker','v','MarkerEdgeColor','[0.2 0.2 0.2]','MarkerFaceColor','[0.2 0.2 0.2]','SizeData',20)
scatter([3,3],b3_14,'Marker','v','MarkerEdgeColor','[0.64 0.08 0.18]','MarkerFaceColor','[0.64 0.08 0.18]','SizeData',20)
scatter([3,3],b3_14v,'Marker','v','MarkerEdgeColor','[0.2 0.2 0.2]','MarkerFaceColor','[0.2 0.2 0.2]','SizeData',20)
scatter([4,4],b4_14,'Marker','v','MarkerEdgeColor','[0.64 0.08 0.18]','MarkerFaceColor','[0.64 0.08 0.18]','SizeData',20)
scatter([4,4],b4_14v,'Marker','v','MarkerEdgeColor','[0.2 0.2 0.2]','MarkerFaceColor','[0.2 0.2 0.2]','SizeData',20)
set( gca, 'YDir', 'reverse','YMinorGrid','on','FontSize',20)
camroll(90);
ylim([-6 6])
ylabel('ms^-^1')
xlabel('cm')
%title('Run 2')
grid on

subplot(2,2,3)
violinplot(Trackf16(:,2),x_Trackf16,'HalfViolin','right','ViolinColor',[0.92,0.58,0.64],'ShowData',false,'ShowMean', true,'EdgeColor',[0.64 0.08 0.18],'ViolinAlpha',0.6,'Width',0.5,'Bandwidth',.3,'QuartileStyle','none','MarkerSize',100);
violinplot(Trackf16(:,3),x_Trackf16,'HalfViolin','left', 'ViolinColor',[0.40,0.40,0.40],'ShowData',false,'ShowMean', true,'EdgeColor',[0.3 0.3 0.3],'ViolinAlpha',0.6,'Width',0.5,'Bandwidth',.3,'QuartileStyle','none','MarkerSize',100);hold on
scatter([1,1],b1_16,'Marker','v','MarkerEdgeColor','[0.64 0.08 0.18]','MarkerFaceColor','[0.64 0.08 0.18]','SizeData',20)
scatter([1,1],b1_16v,'Marker','v','MarkerEdgeColor','[0.2 0.2 0.2]','MarkerFaceColor','[0.2 0.2 0.2]','SizeData',20)
scatter([2,2],b2_16,'Marker','v','MarkerEdgeColor','[0.64 0.08 0.18]','MarkerFaceColor','[0.64 0.08 0.18]','SizeData',20)
scatter([2,2],b2_16v,'Marker','v','MarkerEdgeColor','[0.2 0.2 0.2]','MarkerFaceColor','[0.2 0.2 0.2]','SizeData',20)
scatter([3,3],b3_16,'Marker','v','MarkerEdgeColor','[0.64 0.08 0.18]','MarkerFaceColor','[0.64 0.08 0.18]','SizeData',20)
scatter([3,3],b3_16v,'Marker','v','MarkerEdgeColor','[0.2 0.2 0.2]','MarkerFaceColor','[0.2 0.2 0.2]','SizeData',20)
scatter([4,4],b4_16,'Marker','v','MarkerEdgeColor','[0.64 0.08 0.18]','MarkerFaceColor','[0.64 0.08 0.18]','SizeData',20)
scatter([4,4],b4_16v,'Marker','v','MarkerEdgeColor','[0.2 0.2 0.2]','MarkerFaceColor','[0.2 0.2 0.2]','SizeData',20)

set( gca, 'YDir', 'reverse','YMinorGrid','on','FontSize',20)
camroll(90);
ylim([-6 6])
ylabel('ms^-^1')
xlabel('cm')
%title('Run 4')
grid on

subplot(2,2,4)
violinplot(Trackf17(:,2),x_Trackf17,'HalfViolin','right','ViolinColor',[0.92,0.58,0.64],'ShowData',false,'ShowMean', true,'EdgeColor',[0.64 0.08 0.18],'ViolinAlpha',0.6,'Width',0.5,'Bandwidth',.3,'QuartileStyle','none','MarkerSize',100);
violinplot(Trackf17(:,3),x_Trackf17,'HalfViolin','left', 'ViolinColor',[0.40,0.40,0.40],'ShowData',false,'ShowMean', true,'EdgeColor',[0.3 0.3 0.3],'ViolinAlpha',0.6,'Width',0.5,'Bandwidth',.3,'QuartileStyle','none','MarkerSize',100);hold on
scatter([1,1],b1_17,'Marker','v','MarkerEdgeColor','[0.64 0.08 0.18]','MarkerFaceColor','[0.64 0.08 0.18]','SizeData',20)
scatter([1,1],b1_17v,'Marker','v','MarkerEdgeColor','[0.2 0.2 0.2]','MarkerFaceColor','[0.2 0.2 0.2]','SizeData',20)
scatter([2,2],b2_17,'Marker','v','MarkerEdgeColor','[0.64 0.08 0.18]','MarkerFaceColor','[0.64 0.08 0.18]','SizeData',20)
scatter([2,2],b2_17v,'Marker','v','MarkerEdgeColor','[0.2 0.2 0.2]','MarkerFaceColor','[0.2 0.2 0.2]','SizeData',20)
scatter([3,3],b3_17,'Marker','v','MarkerEdgeColor','[0.64 0.08 0.18]','MarkerFaceColor','[0.64 0.08 0.18]','SizeData',20)
scatter([3,3],b3_17v,'Marker','v','MarkerEdgeColor','[0.2 0.2 0.2]','MarkerFaceColor','[0.2 0.2 0.2]','SizeData',20)
scatter([4,4],b4_17,'Marker','v','MarkerEdgeColor','[0.64 0.08 0.18]','MarkerFaceColor','[0.64 0.08 0.18]','SizeData',20)
scatter([4,4],b4_17v,'Marker','v','MarkerEdgeColor','[0.2 0.2 0.2]','MarkerFaceColor','[0.2 0.2 0.2]','SizeData',20)

set( gca, 'YDir', 'reverse','YMinorGrid','on','FontSize',20)
camroll(90);
ylim([-6 6])
ylabel('ms^-^1')
xlabel('cm')
%title('Run 5')
grid on



%% Supplimental Histograms

clc
figure (888)
clf
subplot(4,1,4)
histogram(Flat17Tracksb1.velx,'BinWidth',0.2,'Normalization', 'pdf');
ylim([0 1])
ylabel('PDF')
xlabel('u-velocities (ms^-^1)')
xlim([-6 6])
set(gca, 'FontSize',30)
grid on
subplot(4,1,3)
histogram(Flat17Tracksb2.velx,'BinWidth',0.2,'Normalization', 'pdf');
ylim([0 1])
ylabel('PDF')
xlim([-6 6])
%xlabel('U-Velocities (0.5-1cm AB')
set(gca, 'FontSize',30)
grid on
subplot(4,1,2)
histogram(Flat17Tracksb3.velx,'BinWidth',0.2,'Normalization', 'pdf');
ylim([0 1])
ylabel('PDF')
xlim([-6 6])
%xlabel('U-Velocities (1-2cm AB')
set(gca, 'FontSize',30)
grid on
subplot(4,1,1)
histogram(Flat17Tracksb4.velx,'BinWidth',0.2,'Normalization', 'pdf');
ylim([0 1])
ylabel('PDF')
xlim([-6 6])
%xlabel('U-Velocities (2-4cm AB')
set(gca, 'FontSize',30)
grid on
title('Run 5 (U=9.1ms^-^1)')
